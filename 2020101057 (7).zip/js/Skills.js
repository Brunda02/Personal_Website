window.onscroll = function() {myFunction()};
 
 var navlist = document.getElementById("navi");
 var sticky = navlist.offsetTop;

 function myFunction() {
     if (window.pageYOffset >= sticky) {
         navlist.classList.add("sticky")
     } 
     else {
         navlist.classList.remove("sticky");
     }
 }
 var array = new Array();
 var dict ={};
 var i=0;
 var name,skill,level;

 function myFunction(){
   i=i+1;  
   var tbl = document.getElementById("Mytable");
   var row=tbl.insertRow();
   var cell1=row.insertCell();
   var cell2=row.insertCell();
   var cell3=row.insertCell();
   cell1.innerHTML = document.getElementById("pname").value;
   var var1 = cell1.innerHTML
   array.push(var1);
   name= "name"+i;
   dict[name]=var1;
   cell2.innerHTML = document.getElementById("pskill").value;
   var var2 = cell2.innerHTML
   array.push(var2);
   skill = "skill"+i
   dict[skill]=var2;
   cell3.innerHTML = document.getElementById("plevel").value;
   var var3 = cell3.innerHTML
   array.push(var3);
   level = "level"+i;
   dict[level]=var3;
 } 

 function bigImg(x) {
  x.classList.add("change");
}

function normalImg(x) {
  x.classList.remove("change");
}