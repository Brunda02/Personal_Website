
var slides=document.querySelector('.slider-items').children;
var index=0;
var i;
function next1(){
  index=1;
  
 for(i=0;i<slides.length;i++){
         slides[i].classList.remove("active");
 }
 slides[index].classList.add("active");   

}

function next2(){
   index=2;
   
  for(i=0;i<slides.length;i++){
          slides[i].classList.remove("active");
  }
  slides[index].classList.add("active");   

}

function next3(){
   index=3;
   
  for(i=0;i<slides.length;i++){
          slides[i].classList.remove("active");
  }
  slides[index].classList.add("active");   
}

function next4(){
   index=4;
   
  for(i=0;i<slides.length;i++){
          slides[i].classList.remove("active");
  }
  slides[index].classList.add("active");   
}

function next5(){
   index=0;
   
  for(i=0;i<slides.length;i++){
          slides[i].classList.remove("active");
  }
  slides[index].classList.add("active");   
}

window.onscroll = function() {myFunction()};
 
  var navlist = document.getElementById("navi");
  var sticky = navlist.offsetTop;
 
  function myFunction() {
      if (window.pageYOffset >= sticky) {
          navlist.classList.add("sticky")
      } 
      else {
          navlist.classList.remove("sticky");
      }
  }

  function bigImg(x) {
  x.classList.add("change");
}

function normalImg(x) {
  x.classList.remove("change");
}  

function myFunction2() {
  var x = document.getElementById("navi");

  if (x.className === "topnav") {
    x.className += " responsive";
  } else {
    x.className = "topnav";
  }
  
}

