window.onscroll = function() {myFunction()};
 
var navlist = document.getElementById("navi");
var sticky = navlist.offsetTop;

function myFunction() {
    if (window.pageYOffset >= sticky) {
        navlist.classList.add("sticky")
    } 
    else {
        navlist.classList.remove("sticky");
    }
}

function bigImg(x) {
x.classList.add("change");
}

function normalImg(x) {
x.classList.remove("change");
}